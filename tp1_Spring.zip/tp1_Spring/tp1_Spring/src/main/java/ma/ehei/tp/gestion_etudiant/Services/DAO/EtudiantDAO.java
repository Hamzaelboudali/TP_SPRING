package ma.ehei.tp.gestion_etudiant.Services.DAO;

import ma.ehei.tp.gestion_etudiant.Models.Etudiant;

public interface EtudiantDAO {

    void persist(Etudiant etudiant);
}
