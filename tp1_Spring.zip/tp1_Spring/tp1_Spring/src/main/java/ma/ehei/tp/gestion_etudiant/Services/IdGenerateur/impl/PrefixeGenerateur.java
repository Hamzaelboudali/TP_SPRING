package ma.ehei.tp.gestion_etudiant.Services.IdGenerateur.impl;

import ma.ehei.tp.gestion_etudiant.Services.IdGenerateur.IdGenerateur;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Qualifier("PrefixeGenerateur")
public class PrefixeGenerateur implements IdGenerateur {

    private int counter = 0;
    private final String STUDENT_PREFIX = "ETUD-";
    @Override
    public String GenererID() {
        return STUDENT_PREFIX + (++counter);
    }
}
