package ma.ehei.tp.gestion_etudiant.Services;

import ma.ehei.tp.gestion_etudiant.Models.Etudiant;
import ma.ehei.tp.gestion_etudiant.Services.DAO.EtudiantDAO;
import ma.ehei.tp.gestion_etudiant.Services.IdGenerateur.IdGenerateur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class EtudiantService {
    @Qualifier("MemoireDAO")
    @Autowired
    private EtudiantDAO etudiantDAO;
    @Qualifier("TimeStampIdGenerateur")
    @Autowired
    private IdGenerateur idGenerateur;

    public void add(Etudiant etudiant){
        String id = idGenerateur.GenererID();
        etudiant.setId(id);
        etudiant.setNom("hashas");
        etudiant.setPrenom("jad el mawla");
        etudiantDAO.persist(etudiant);
        System.out.println("Etudiant est ajouter ");
    }
}
