package ma.ehei.tp.gestion_etudiant.Configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages ="ma.ehei.tp.gestion_etudiant")
public class AppConfig {
}
