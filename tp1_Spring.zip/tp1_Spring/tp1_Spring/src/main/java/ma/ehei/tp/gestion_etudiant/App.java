package ma.ehei.tp.gestion_etudiant;

import ma.ehei.tp.gestion_etudiant.Models.Etudiant;
import ma.ehei.tp.gestion_etudiant.Services.EtudiantService;
import ma.ehei.tp.gestion_etudiant.Configuration.AppConfig;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class App {
    public static void main(String[] args) {

        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        Etudiant etudiant = new Etudiant();

        EtudiantService etudiantService = context.getBean(EtudiantService.class);
        etudiantService.add(etudiant);
    }
}
