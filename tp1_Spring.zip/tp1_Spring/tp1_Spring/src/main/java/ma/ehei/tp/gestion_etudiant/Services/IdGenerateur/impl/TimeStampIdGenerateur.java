package ma.ehei.tp.gestion_etudiant.Services.IdGenerateur.impl;


import ma.ehei.tp.gestion_etudiant.Services.IdGenerateur.IdGenerateur;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.UUID;
@Service
@Qualifier("TimeStampIdGenerateur")
public class TimeStampIdGenerateur implements IdGenerateur {
    @Override
    public String GenererID() {
        long timestamp = System.currentTimeMillis();
        return timestamp + "-" + UUID.randomUUID();
    }
}
