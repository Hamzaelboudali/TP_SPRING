package ma.ehei.tp.gestion_etudiant.Services.IdGenerateur.impl;

import ma.ehei.tp.gestion_etudiant.Services.IdGenerateur.IdGenerateur;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
@Qualifier("AutoAutoIcrementGenereteur")
public class AutoIcrementGenereteur implements IdGenerateur {
    private int counter = 0;
    @Override
    public String GenererID() {
        return Integer.toString(++counter);
    }
}
