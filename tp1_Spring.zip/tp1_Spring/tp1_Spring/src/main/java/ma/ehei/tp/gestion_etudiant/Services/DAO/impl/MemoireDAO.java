package ma.ehei.tp.gestion_etudiant.Services.DAO.impl;

import ma.ehei.tp.gestion_etudiant.Models.Etudiant;
import ma.ehei.tp.gestion_etudiant.Services.DAO.EtudiantDAO;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
@Qualifier("MemoireDAO")
public class MemoireDAO implements EtudiantDAO {
    ArrayList<Etudiant> etudiants = new ArrayList<>();
    @Override
    public void persist(Etudiant etudiant) {
        etudiants.add(etudiant);
        System.out.println("etudiant bien persister dans la memoire");
        for (Etudiant etu : etudiants){
            System.out.println(etu.toString());
        }
    }
}
