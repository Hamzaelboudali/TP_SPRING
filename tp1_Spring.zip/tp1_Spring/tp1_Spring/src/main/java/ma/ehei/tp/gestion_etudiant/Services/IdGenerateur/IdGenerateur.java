package ma.ehei.tp.gestion_etudiant.Services.IdGenerateur;

public interface IdGenerateur {
    String GenererID();
}
