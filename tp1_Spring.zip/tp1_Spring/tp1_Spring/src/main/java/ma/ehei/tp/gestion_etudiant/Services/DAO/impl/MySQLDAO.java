package ma.ehei.tp.gestion_etudiant.Services.DAO.impl;

import ma.ehei.tp.gestion_etudiant.Models.Etudiant;
import ma.ehei.tp.gestion_etudiant.Services.DAO.EtudiantDAO;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
@Qualifier("MySQLDAO")
public class MySQLDAO implements EtudiantDAO {
    @Override
    public void persist(Etudiant etudiant) {
        System.out.println("etudiant bien persister dans un bd MySql");
    }
}
