package ma.ehie.tp.gestion_facturation.service.facturation;

import ma.ehie.tp.gestion_facturation.service.reduction.reductionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service  // @Component + bean responsable sur la gestion et des traitement fonctionnelle
// ou
//@Component
public class facturationService {
    @Qualifier("sansReductionService")
    @Autowired   // demander une injection depuis spring
    private reductionService reductionService;
    public Double appliquerReduction(Double montant){
        return montant - reductionService.callculerReuction(montant);   // delegation et confier se dossier a un autre dossier
        // c est pas mon objetife de connaitre comment callculer cette reduction , principe important : S : singel responsabiliter
    }

}
