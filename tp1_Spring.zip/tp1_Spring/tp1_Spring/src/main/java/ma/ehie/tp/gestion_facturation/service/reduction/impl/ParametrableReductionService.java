package ma.ehie.tp.gestion_facturation.service.reduction.impl;

import ma.ehie.tp.gestion_facturation.service.reduction.reductionService;
import org.springframework.stereotype.Service;

@Service
public class ParametrableReductionService implements reductionService {
    @Override
    public double callculerReuction(Double montant) {
        return montant * 10 / 100;
    }
}
