package ma.ehie.tp.gestion_facturation.service.reduction;

public interface reductionService {
    double callculerReuction(Double montant);
}
