package ma.ehie.tp.gestion_facturation;

import ma.ehie.tp.gestion_facturation.configuration.AppConfig;
import ma.ehie.tp.gestion_facturation.service.facturation.facturationService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class TpFacturationCorrectionProfApplication {

    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
//        ApplicationContext context = new AnnotationConfigApplicationContext("ma.ehei.tp.gestion_facturation");  solution limiter
        facturationService facturationService =  context.getBean(facturationService.class);
        Double montantAvecReduction = facturationService.appliquerReduction(1000.0);
        System.out.println(montantAvecReduction);
    }

}
