package ma.ehie.tp.gestion_facturation.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages = "ma.ehie.tp.gestion_facturation")  // scanner et fait la recherche des beans qui se trouve dans se package (pachage racine)
//@PropertySource("classpath.app.properties")
//@ImportResource("classpath:spring-config.xml")
public class AppConfig {

}
