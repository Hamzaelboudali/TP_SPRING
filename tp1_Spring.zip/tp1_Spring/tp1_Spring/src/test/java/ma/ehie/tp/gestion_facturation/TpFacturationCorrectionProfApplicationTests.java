package ma.ehie.tp.gestion_facturation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpFacturationCorrectionProfApplicationTests {

    @Test
    void contextLoads() {
    }

}
